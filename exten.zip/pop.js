chrome.tabs.query({
		currentWindow: true,
		active: true
	
	}, function(tab) {
			iframeWalaFunction(tab[0].url)
	});
//alert(1)
//iframeWalaFunction("https://numberless-holddown.000webhostapp.com/dashboard/")
function iframeWalaFunction(url){
	   document.getElementById("p1").innerHTML = '<div style="text-align:center">	<h1 style="text-align:center">POC Of <b style="color:red">CLICKJACKING</b> Vulnerability</h1><iframe src="'+url+'" style="text-align:center border:2px="" solid="" red;="" width="600" height="400" ></iframe></div>';
}

